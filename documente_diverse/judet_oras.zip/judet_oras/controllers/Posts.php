<?php
class Posts extends CI_Controller {

	// or
			//function __construct() {
			//	parent::__construct();
			//	if(!$this->session->userdata('logged_in')){
			//	redirect('users/login');				}
			//}

       public function index()
		{
        $data['title'] = 'Latest Post'; // Capitalize the first letter
        $data['posts'] = $this->post_model->get_posts();

        $this->load->view('templates/header', $data);
        $this->load->view('posts/index', $data);
        $this->load->view('templates/footer', $data);
		}
		public function view($city=NULL)
		{
			$data['post'] = $this->post_model->get_posts($city);
			
			if(empty($data['post']))
			{
				show_404();
			}
			$data['title'] = $data['post']['county2'];
			$this->load->view('templates/header', $data);
        	$this->load->view('posts/view', $data);
       		$this->load->view('templates/footer', $data);
		}

		public function create_patient() {
			//Check loggin
			if(!$this->session->userdata('logged_in')){
				redirect('users/login');
			}

		
			$data['title'] = 'Create patient';

			$data['countys'] = $this->post_model->get_countys();

			$this->form_validation->set_rules('first_name','First Name','required');
			$this->form_validation->set_rules('last_name','Last Name','required');
			$this->form_validation->set_rules('cnp','CNP','required');
			$this->form_validation->set_rules('county','County','required');
			$this->form_validation->set_rules('city','City','required');
			$this->form_validation->set_rules('adress','Adress','required');
			$this->form_validation->set_rules('profession','Profession','required');
			$this->form_validation->set_rules('workplace','Workplace','required');
			$this->form_validation->set_rules('phone','Phone','required');
			$this->form_validation->set_rules('email','Email','required');
			$this->form_validation->set_rules('marital_status','Marital Status','required');
			
	if($this->form_validation->run() === FALSE) {
			$this->load->view('templates/header', $data);
        	$this->load->view('posts/create_patient', $data);
       		//$this->load->view('templates/footer', $data);
       	} else {
       		$this->post_model->create_patient_posts();
       		//$this->load->view('posts/success');
       		// Set message
       		$this->session->set_flashdata('patient_created','Your patient was created');
       		
       		redirect('home');
       	}
		
	} // create_patient

	public function get_city(){
		$county2=$this->input->post('county2');
		
		$citys=$this->post_model->get_city($county2);
		
		if(count($citys)>0)
		{
			$city_select_box = '';
				
			
			$city_select_box .= '<option>Select City</option>';
			foreach($citys as $city) {
				
				$city_select_box .= '<option>'.$city->city.'</option>'; 
			}
			
			echo json_encode($city_select_box) ;
		}

	} //get_city


	public function create_dic_examination() {
		//Check loggin
			if(!$this->session->userdata('logged_in')){
				redirect('users/login') ;
			}
		
			$this->form_validation->set_rules('examination_type','Examination _Type','required');
			$this->form_validation->set_rules('price','Price','required');
			$this->form_validation->set_rules('from_date','From Date','required');
			
			 $data['title'] = 'Entry dic_examination value'; 
	if($this->form_validation->run() === FALSE) {
			$this->load->view('templates/header', $data);
        	$this->load->view('posts/create_dic_examination', $data);
       		$this->load->view('templates/footer', $data);
       	} else {
       		$this->post_model->create_dic_examination_posts();
		// Set message
       		$this->session->set_flashdata('dic_examinationt_created','Your dic_examination was created');

       		//$this->load->view('posts/success_search');
       		redirect('Posts/create_dic_examination');
       	}
		
	} // create_dic_examination

	public function search_dic_examination($offset=0) {
		//Check loggin
			if(!$this->session->userdata('logged_in')){
				redirect('users/login');
			}
			$this->load->library('pagination');
      		
      		$config['base_url'] = site_url('posts/search_dic_examination');
      		$config['total_rows'] = $this->post_model->countAll();
			$config['per_page'] = 4;

			$this->pagination->initialize($config);

			$data['title'] = 'Search dic_examination value'; 

			$this->load->model('post_model');
			$data['dic_examination'] = $this->post_model->search_dic_examination_posts($config['per_page'], $offset);

			$this->load->view('templates/header', $data);
       		$this->load->view('posts/search_dic_examination', $data);
       		//$this->load->view('templates/footer', $data);
	} // search_dic_examination

	public function edit_dic_examination($dic_examination_id) {
			$data['title'] = 'Edit dic_examination value'; 

			$data['dic_examination'] = $this->post_model->getById_dic_examination($dic_examination_id);
			$this->load->view('templates/header', $data);
        	$this->load->view('posts/edit_dic_examination', $data);

	} //edit_dic_examination

	public function update_dic_examination($dic_examination_id) {

			$this->post_model->update_dic_examination($dic_examination_id);
		// Set message
       		$this->session->set_flashdata('dic_examination_updated','Your dic_examination was updated');
       		redirect('Posts/search_dic_examination');
	} //

	public function delete_dic_examination($dic_examination_id){
			$this->post_model->delete_dic_examination($dic_examination_id);

			$this->session->set_flashdata('dic_examination_deleted','Your dic_examination was deleted');
       		redirect('Posts/search_dic_examination');
	}



			//$data['title'] = 'Search dic_examination value'; 
		//	$this->load->view('templates/header', $data);
        //	$this->load->view('posts/search_dic_examination', $data);
       	//	$this->load->view('templates/footer', $data);
       	
			
       	//	$data['posts'] = $this->post_model->search_dic_examination_posts();

			//print_r($data);

			//if(empty($data['post']))

		//	if(empty($data['price']))
		//	{
				//show_404();
			//	$this->load->view('posts/success');
		//	}
			//$data['title'] = $data['post']['examination_type'];
		//	$data['title'] = 'Afisare date rezultate in urma cautarii';

		//	$this->load->view('templates/header', $data);
       		//$this->load->view('posts/success_search');
       		//$this->load->view('templates/footer', $data);
       		//redirect('Posts/create_dic_examination');
       	
		
	

} // CI_controler
