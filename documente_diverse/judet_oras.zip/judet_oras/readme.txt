Am pus alaturat codul penntru accesare judet, oras din liste.
pentru incarcare oras se utilizeaza:
--din view/posts/create_patient.php --> scriptul javascript de la sfarsit
--din models/post_model.php --> functiile get_county() si get_city($county2)
--din controllers/posts/posts.php  --> functia get_city()