<?php
class Post_model extends CI_model {
	public function __construct() {
		$this->load->database();
	} 

	public function get_posts($city = FALSE) {
		if ($city === FALSE) {
			$this->db->order_by('dic_city_id','DESC');
			$query = $this->db->get('dic_city');
			return $query->result_array();
		}
		
			$query = $this->db->get_where('dic_city', array('city' => $city));
			
			return $query->row_array();

	}

	public function create_patient_posts() {
		//print_r($this->input->post('first_name');
		//$data['title'] = 'Dates patient aaa'; 
		$dic_city_id='1';
		$data = array(
			'first_name' => $this->input->post('first_name'),
			'last_name' => $this->input->post('last_name'),
			'cnp' => $this->input->post('cnp'),
			'dic_city_id' => $dic_city_id,
			'adress' => $this->input->post('adress'),
			'profession' => $this->input->post('profession'),
			'workplace' => $this->input->post('workplace'),
			'phone' => $this->input->post('phone'),
			'email' => $this->input->post('email'),
			'marital_status' => $this->input->post('marital_status')
		);
		return $this->db->insert('patient',$data) ;
	}

	public function create_dic_examination_posts() {
		
		$data = array(
			'examination_type' => $this->input->post('examination_type'),
			'price' => $this->input->post('price'),
			'from_date' => $this->input->post('from_date'),
			'to_date' => $this->input->post('to_date'),
		);
		return $this->db->insert('dic_examination',$data) ;
	} // create_dic_examination_posts


		public function search_dic_examination_posts($limit, $offset) {  //get All
				$this->db->limit($limit);
				$this->db->offset($offset);
				$this->db->order_by('dic_examination_id DESC');
				return $this->db->get('dic_examination')->result();

	} // search_dic_examination_posts
		public function countAll(){
				return $this->db->get('dic_examination')->num_rows();
		}


		public function getById_dic_examination($dic_examination_id){
			return $this->db->get_where('dic_examination',array('dic_examination_id'=>$dic_examination_id))->row();
	}

		public function update_dic_examination($dic_examination_id) {
		
		$data = array(
			'examination_type' => $this->input->post('examination_type'),
			'price' => $this->input->post('price'),
			'from_date' => $this->input->post('from_date'),
			'to_date' => $this->input->post('to_date')
			);
			$this->db->where(array('dic_examination_id'=>$dic_examination_id));
			$this->db->update('dic_examination',$data) ;
	} // create_dic_examination_posts

		public function delete_dic_examination($dic_examination_id) {
			$this->db->where(array('dic_examination_id'=>$dic_examination_id));
			$this->db->delete('dic_examination');


		}




		//	$examination_type = $this->input->post('examination_type');
		//	$price = $this->input->post('price');
		//	$from_date = $this->input->post('from_date');
		//	$to_date = $this->input->post('to_date');
			//construiesc $sirwhere
			//$sirwhere='';
			//if (!empty($examination_type)) {
			//	$array[] = array('examination_type' => $examination_type);
				//}
		//	if (!empty($price)) {
			//	$array[] = array('price' => $price);
			//	}	
			//if (!empty($from_date)) {
			//	$array[] =array('from_date' => $from_date);
			//	}
			//if (!empty($from_date)) {
			//	$array[] =array('to_date' => $to_date);
			//	}	
			//if (empty($array)) {
				//$this->db->order_by('examination_type','DESC');
			//	$query = $this->db->get('dic_examination');
			//	return $query->result_array();
				//} else
				//{
					//print_r($array);
				//$query = $this->db->get_where('dic_examination', array('examination_type' => $examination_type));
				//return $query->row_array();
				//}


	public function get_countys() {
		$this->db->order_by('county');
		$query = $this->db->get('dic_county');
		return $query->result_array();
	} // get_countys

	public function get_city($county2){
		
		$query = $this->db->get_where('dic_city', array('county2' => $county2));
		
		return $query->result();
	} //get_city


} //CI_model